#pragma once
class Csection_6
{
	int eg6_1();
	void RowSum(int A[][4], int nrow);
	void eg6_2(void);
	int eg6_5();
	int eg6_7_1();
	int eg6_7_2();
	int eg6_7_3();
	void eg6_8();
	void eg6_9();
	void splitfloat(float x, int *intpart, float *fracpart);
	void eg6_10();
public:
	Csection_6();
	~Csection_6();
};

