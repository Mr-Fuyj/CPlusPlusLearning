#pragma once
class Csection_2
{
public:
	int eg2_1();
	int eg2_2();
	int eg2_3();
	int eg2_4();
	int eg2_5();
	int eg2_6();
	int eg2_7();
	int eg2_8();
	int eg2_9();
	int eg2_10();
	int eg2_11();
public:
	Csection_2();
	virtual ~Csection_2();
};

