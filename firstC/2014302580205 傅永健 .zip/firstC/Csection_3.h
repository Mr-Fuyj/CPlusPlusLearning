#pragma once
class Csection_3
{
public:
	double power(double x, int n);
	int change(char*ch);
	void test_1();
	double arctan(double x);
	bool symm(long n);
	double tsin(double x);
	int rolldice();
	int test_2();
	int test_3();
	int fun1(int x, int y);
	int fun2(int m);
	long fac(int n);
	int comm(int n, int k);
	void move(char getone, char putone);
	void hanoi(int n, char one, char two, char three);
	int test_4();
	void Swap(int &a, int &b);
	inline double CalArea(double radius);
	int get_volume(int length, int width = 2, int height = 3);
	int sum_of_square(int a, int b);
	double sum_of_square(double a, double b);
	int test_5();
public:
	Csection_3();
	virtual ~Csection_3();
};

